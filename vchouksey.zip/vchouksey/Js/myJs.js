


         
var noteData = '<div class="note col-md-3">'
       + '<p>I would like to commend your employee Vikas on a recent interaction. Unfortunately I had to follow up a couple of times on a request for work and in a way I am so glad as I had the pleasure to deal with Vikas as a result.</p>'
       + '<p>He has been prompt, diligent in his delivery and extremely patient when my business partner required a further 2 changes which he was able to arrange to be changed, tested and put into production in 2 days. </p>'

       + '<p>The recent Service Promise that has been launched, Vikas has certainly taken on board the behaviours and is an outstanding example of the motto ‘We are people always helping people’.</p>'
       + '<p>If you have an award program, I would certainly appreciate you putting forward this as a nomination</p>'
       + '<b>Liz Znidersic</b>'
        +'</div>'
        
       + '<div class="note col-md-3" id="note" >'
       + '<p>Wanted to appreciate Vikas for all the good work he has done for past 3-4 weeks in supporting HR Onboard project by resolving WIW notification issues.</p>'
       + '<p>He has been prompt and methodological in his approach, communicated clearly and kept us informed on the progress of the work.</p>'

        + '<p>I want to say thanks to you as well for assigning such a valuable resource for resolving double notification issues. He has been a great help to the HR Onboard project team.</p>'
       + '<b>Manoj Mishra</b>'
        + '</div> '


        + '<div class="note col-md-3" >'
        +'<p>I just want to pass on my appreciation of Vikas’ work.</p>'
        +'<p>I’ve worked with him on a couple of major releases for the Gifts & Hospitality Register. On both occasions, he has delivered great work! It is so refreshing to work with someone who is always willing to help and always delivers quality work.</p>'

        +'<p>The ABC Project and the owners of the G&H Register also acknowledge Vikas and the DAS team’s work and support. So please extend our THANKS to Vikas and the team for delivering great work!</p>'
        +'<b >Prescy Giron</b>'
         +'</div> '

         +'<div class="note col-md-3" >'
        +'<p>I would like to appreciate the positive work attitude of your team DAS and the way they handle queries and issues received for WRAP application or for any other application .</p>'
        +'<p>Specially Vikas Chouksey with whom I always to want to talk because of wonderful nature and quick issue resolving skills , he is best team member , I have interacted for far .</p>'
 
        +'<p>Vikas has always welcome nature due to which I can approach him any time , any day for any kind of issue or problem and I always get answer or solution to my issues .</p>'
 
        +'<p>At last I would like to thank you Vikas for helping me and really appreciate your ready to do attitude .</p>'
 
        +'<b >Girdhar Sharma</b>'

         +'</div> '

        +'<div class="note col-md-3" >'
        

        +'<p>Hope your well. I thought I should share some feedback about Vikas Chouksey only because when someone is doing an amazing job it’s only fair their manager is aware of it. </p>'
        +'<p>To let you know, I’ve dealt with Vikas for the the past year and every occasion not only has he been pleasant to deal with, his response time to emails has always been prompt and most importantly the actioning of the emails has been outstanding and I thought it’s important to share this with yourself.</p>'


        +'<b>Ammara Riaz</b>'
        +'</div>'
         +'<div class="note col-md-3" id="note1" >'
        +'<p>Love your work Vikas!!!</p>'

        +'<p>People rarely take the time, to thank people for their efforts verbally, it is even rarer that they make the effort to do it by email. So I know when I see one of these sort of emails the team member involved has done an outstanding job. </p><br>'

        +'<p>Thanks so much for your dedication, excellent customer service, focus and technical skill. It reflects really well on the entire teams reputation but most of all it reflects well on you.</p>'


        +'<b>Craig Georgans</b>'

         +'</div>' 

         $(document).ready(function() {
    $(noteData).appendTo("#board");
    
});